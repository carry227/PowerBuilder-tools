About PBHelper(PBCOMMENT) Version 1.0.2
Upgrade from PBCOMMENT 7.0
================================================================
Copyright (c) 1999-2000 RC Sizer, All rights reserved.
Copyright (c) 2003-2006 Welkin, All rights reserved.
Copyright (c) 2002-2006 TRUEWAY(TM), All rights reserved.
TRUEWAY(TM) is the trademark of programs by Trueway Lee


   She can help you to create comments for PB script automatically,
and indent some PB script at sixes and sevens into dainty format.
   And she can also help you automaticly create script code.
   She is really wonderful!!!

   Support PowerBuilder 6.x/7.0/8.0/9.0/10.0/10.5/11.0 in one program!!! 


   You can also read <<readme_cn.txt>> written in simple chinese.


   I usually appreciate an email describing how you used 
the code and what modifications (if any) where made to the code.    
   My E-Mail: truewaylee@hotmail.com

   PBHelper URL:
   http://gforge.osdn.net.cn/projects/pbhelper/

    
Function Specification
================================================================
   The lastest PBHelper(PBCOMMENT) include some useful functions, 
such as:
     Build complete function comment
     Build modify/delete/add code comment
     Build step code specification comment
     Convert the script text to UpperCase/LowerCase
     Indent your PB script code, a powerful function to turn your
        PB script code into dainty format!!!
     Automatically fill prefix or postfix into a block of script code
     Automatically fill script code between datawindow and structure 
        variable, or datawindow and datawindow, and so on.
     DataWindow script code automatic create tool

What's New of PBHelper(PBCOMMENT)
================================================================
   PBCOMMENT Version 1.0     Only support PB 6.0/6.5
   PBCOMMENT Version 2.0     Added Support PB 7.0
   PBCOMMENT Version 3.0     Added Support PB 8.0
   PBCOMMENT Version 3.5     Added Support PB 9.0
   PBCOMMENT Version 5.0     Added indent script code
   PBCOMMENT Version 5.1     Rewrite the object of PB indent tool
                             Fixed the bug found
   PBCOMMENT Version 5.2     Fixed the bug when process "&"
                             Added Support SQL statement 
                             Fixed the bug when "~~" or "~""
                             Added process *.sr* file in one time
                             Automatically integrate PBCOMMENT to PB IDE
                                Now support PB 6.0/6.5, PB 9.0 only
                             Fixed bug when define a DOUBLE type variable 
   PBCOMMENT Version 5.3     Automatically fill prefix or postfix into 
                                a block of script code
   PBCOMMENT Version 5.31    Automatically fill script code between 
                                datawindow and structure variable, 
                                or datawindow and datawindow
                             Add support for muti-language form
                             Automatically integrate PBCOMMENT to PB IDE
                                Now support PB 6.0/6.5/7.0/8.0/9.0 
                             Add trim code from the beginnig or end the flag
   PBCOMMENT Version 5.5     Add suppprt for dataWindow script code
                                automatic create tool named "PBDataWindow.exe"
                             Add support for distinguishing comment between
                                function or event code under PB 6.0/6.5
   PBCOMMENT Version 5.5 Plus  Add user function for comment interested format
                             Add support for distinguishing comment between
                                function or event code under PB 7.0-9.0             
                                
   PBCOMMENT Version 6.0     Fixed some bug about indent script 
                             Add support for PB 10.0
                             Add support for automatically detect 
                                current PB IDE version
   PBCOMMENT Version 6.1     Fixed some bug about integrate to PB IDE
                             Add multi-language support for function comment
                             Fixed some bug about indent *.sr* file

   PBCOMMENT Version 7.0     Add support for datawindow sql script indent
                                (only in PB 6.0/6.5 datawindow painter)
                             Add automatically build PB script about datawindow
                                e.g.  SetItem, GetItem, and so on.
                                (only in PB 6.0/6.5)

   PBHelper  Version 0.8     The software code name is instead of "PBHelper" 
                             PBHelper first version is V0.8
                             Add support for PB 10.5 beta 1

   PBHelper  Version 0.8.1   Fix a bug about saving indent option 

   PBHelper  Version 0.8.2   Fix a bug when "xxxx // xxxx"
                             Add support "TRY...CATCH...FINALLY...END TRY"
                             Add support template for comment block
                             template0.txt for template in Simple Chinese
                             template1.txt for template in English

   PBHelper  Version 0.8.3   Add support for PB 10.5 beta 2
                             Fix some bugs

   PBHelper  Version 0.8.4   Chinese comment 
                             Fix some bugs
                             Add support for PB 11.0 beta 1

   PBHelper  Version 0.8.5   Add support chinese variable 


   PBHelper  Version 1.0.0   Regenerate all script and new design 
                             New style GUI
                             compose pbcomment.ini and template text file to pbhelper.ini
     
   PBHelper  Version 1.0.1   Fixed bugs when open options windows
                             Fixed a bug for integrated PB IDE toolbar

   PBHelper  Version 1.0.2   Fixed bugs when save options
                             Add support step comment template
                             Add go to URL on about dialog

Reason and History
================================================================
   If you often access internet, you will find a lot of homothetic 
programs they can help you to build code comments automatically. But, 
it is obvious to easily find a fly in the ointment, they can't support 
all PB version Integrated Development Entironment. The lastest PBCOMMENT 
provide with all support.
   Thanks a lot for the program written by RC Sizer who created the frame 
work of PBCOMMENT.
   I am Trueway. I usually appreciate an email describing how you used 
the code and what modifications (if any) where made to the code. 
All feedback will be published in a Frequently Asked Questions (FAQ) page,
with the appropriate references. I'm looking forward to meeting your E-Mail.
   The function to indent script code is written by Welkin Zhou, a excellent 
programmer, come from Hangzhou, a beautiful city of China. He often create
some utility tools they can help you to code freely and joyfully. 
   Thanks a lot for the program written by  Welkin Zhou.
   For rapid coding, from PBCOMMENT 5.3, add support for automaticly complete 
script code, such as: build datawindow script code from datawindow column list,
assign structure variable to datawindow, assign value between one datawindow 
and another, and so on. By this way, you can spend less time on coding. 


PBCOMMENT Usage
================================================================
   The file named "pbhelper.exe" compiled under PB 6.5. Please copy the
PB 6.5 virtual machine files to your windows system directory before use it.
Surely you can compile PBCOMMENT.pbl under PB 6.5 or later version. 
   NOT FORGET to copy the virtual machine files of all version PB to your
windows system directory.
   Under PBCOMMENT 5.2 or later, you can click "Integrate" menu item, 
PBCOMMENT will automatically integrate itself to the current active
or inactive but installed in your system, You can use them looked as 
some powerful tools of great use provided by SYBASE. 

1) Run "pbhelper.exe" directly

2) Run "pbhelper.exe", then click menu item "System"-"Integrate", PBHelper 
will be integrated into your PB IDE as a tools bar.

3) menu "Part Commets",normal tagged comemts in modified status, push ctrl key 
tagged comments in added status,push shift key tagged comments in deleted status.

4) set option by run application.
 